def print_dict_list(items, keys):
    """
    Utility to pretty-print selected fields from a list of dicts.
    """
    for item in items:
        for key in keys:
            print(f"{key}: {item[key]}", end=" | ")
        print()
