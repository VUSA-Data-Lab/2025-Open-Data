def get_top_damage_heroes(heroes, top_n=10):
    """
    Sorts heroes by base_attack_min (closest available field).
    """
    sorted_heroes = sorted(
        heroes,
        key=lambda h: h["base_attack_min"],
        reverse=True
    )
    return sorted_heroes[:top_n]


def count_attack_types(heroes):
    """
    Returns a dict with counts of Melee and Ranged heroes.
    """
    counts = {"Melee": 0, "Ranged": 0}
    for h in heroes:
        counts[h["attack_type"]] += 1
    return counts


def movement_speed_distribution(heroes):
    """
    Returns a list of movement speeds for histogram plotting.
    """
    return [h["move_speed"] for h in heroes]
