import requests

API_URL = "https://api.opendota.com/api/heroStats"

def fetch_hero_data():
    """
    Fetches hero statistics from OpenDota API (heroStats endpoint).
    Returns: list of hero dictionaries.
    """
    response = requests.get(API_URL, timeout=10)
    response.raise_for_status()
    return response.json()
