from data import fetch_hero_data
from processing import (
    get_top_damage_heroes,
    count_attack_types,
    movement_speed_distribution,
)
from visualization import (
    plot_top_damage,
    plot_attack_type_distribution,
    plot_movement_speed_histogram,
)

def main():
    print("Fetching hero data from OpenDota API...")
    heroes = fetch_hero_data()

    print("Processing data...")
    top_damage = get_top_damage_heroes(heroes, top_n=10)
    attack_type_counts = count_attack_types(heroes)
    mspeeds = movement_speed_distribution(heroes)

    print("Generating visualizations...")
    plot_top_damage(top_damage)
    plot_attack_type_distribution(attack_type_counts)
    plot_movement_speed_histogram(mspeeds)

    print("Analysis complete!")

if __name__ == "__main__":
    main()
