import matplotlib.pyplot as plt

def plot_top_damage(top_heroes):
    names = [h["localized_name"] for h in top_heroes]
    values = [h["base_attack_max"] for h in top_heroes]

    plt.figure(figsize=(10, 6))
    plt.bar(names, values)
    plt.xticks(rotation=45, ha="right")
    plt.title("Top 10 Heroes by Base Attack Damage")
    plt.xlabel("Hero")
    plt.ylabel("Base Attack Damage")
    plt.tight_layout()
    plt.show()


def plot_attack_type_distribution(counts):
    labels = list(counts.keys())
    sizes = list(counts.values())

    plt.figure(figsize=(6, 6))
    plt.pie(sizes, labels=labels, autopct="%1.1f%%")
    plt.title("Melee vs Ranged Hero Distribution")
    plt.show()


def plot_movement_speed_histogram(mspeeds):
    plt.figure(figsize=(10, 5))
    plt.hist(mspeeds, bins=10)
    plt.title("Hero Movement Speed Distribution")
    plt.xlabel("Movement Speed")
    plt.ylabel("Number of Heroes")
    plt.tight_layout()
    plt.show()
